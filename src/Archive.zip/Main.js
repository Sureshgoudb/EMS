import React from "react";
import { RouterProvider, createBrowserRouter, Outlet } from "react-router-dom";

import Footer from "./Components/Footer";
import Header from "./Components/Header";
import Users from "./Components/Users";
import Login from "./Components/Login";
import Countries from "./Components/Countries";

const Main = () => {
  const HeaderLayout = () => (
    <>
      <Header />
      
      <Outlet />
      <Footer   />
    </>
  );

  const appRouter = createBrowserRouter([
    {
      element: <HeaderLayout />,
      children: [
        {
          path: "/",
          element: <Login />,
        },
        {
          path: "/users",
          element: <Users />,
        },

        {
          path: "/countries",
          element: <Countries />,
        },
      ],
    },
  ]);

  return (
    <>
      <div className=" mt-20 md:mt-16 sm:mt-16">
        <RouterProvider router={appRouter} />
      </div>
    </>
  );
};

export default Main;
