import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import ThemeSwitcher from "../Helpers/ThemeSwitcher";
import {
 
  Bars3BottomRightIcon,
  XMarkIcon,
  UserCircleIcon,
 GlobeAltIcon,
} from "@heroicons/react/24/solid";


function Header() {
  let pageLinks = [
    { id: 1, name: "", to: "/" },
   
  ];
  let [open, setOpen] = useState(false);

  return (
    <>
    
      <div className="shadow-md w-full fixed top-0 left-0 dark:border-b-2 z-50 border-indigo-600}">
        <div className="md:flex items-center justify-between bg-white dark:bg-black   py-4 md:px-10 px-7">
          {/* logo section */}
          <div className=" hidden md:block lg:block xl:block 2xl:block">
            <div className="font-bold text-2xl cursor-pointer flex items-center gap-1">
            <NavLink to={'/'}>  <GlobeAltIcon className="w-7 h-7 text-blue-600" /></NavLink> 
            <NavLink to={'/'}> <span className=" text-black dark:text-white">Countries Map</span></NavLink>
            </div>
            {/* Menu icon */}
          </div>

          {/* Mobile Nav   */}
          <div className="flex md:hidden lg:hidden xl:hidden 2xl:hidden  flex-row">
            <div className="flex-none ...">
             <NavLink to={'/'} ><GlobeAltIcon className="w-7 h-7 text-blue-600" /></NavLink> 
            </div>
            <div className="flex-1 w-32">
            <NavLink to={'/'} > <span className=" text-black dark:text-white">Praveen</span></NavLink> 
            </div>
            <div className="flex-1 w-32">
              <ThemeSwitcher />
            </div>
            <div
              className="flex-1 w-10 h-12  absolute right-8 top-3 items-center dark:text-white"
              onClick={() => setOpen(!open)}
            >
              {open ? (
                <XMarkIcon className=" dark:text-white" />
              ) : (
                <Bars3BottomRightIcon />
              )}
            </div>
          </div>

          {/* linke items */}
          <ul
            className={` dark:bg-black  bg-white md:bg-none lg:bg-none md:flex  md:items-center md:pb-0 pb-12 absolute md:static  md:z-auto z-[-1] left-0 w-full md:w-auto md:pl-0 pl-9 transition-all duration-500 ease-in ${
              open ? "top-12" : "top-[-490px] "
            }`}
          >
            {pageLinks.map((pageLink) => (
              <li
                className="md:ml-3 md:my-0 my-2 font-semibold"
                key={pageLink.id}
              >
                <Link
                  to={pageLink.to}
                  key={pageLink.id}
                  className="text-gray-800 dark:text-white hover:bg-none hover:border-b-4 hover:border-green-600 hover:text-blue-400 duration-500"
                >
                  {pageLink.name}
                </Link>
              </li>
            ))}
           
            {/* <div className="btn font-semibold px-3 py-1 rounded duration-500  md:ml-8  ">
              <UserCircleIcon />
            </div> */}
            <div className="btn font-semibold px-3 py-1 rounded duration-500  md:ml-8 hidden md:block lg:block xl:block 2xl:block ">
              <ThemeSwitcher />
            </div>
          </ul>
        </div>
        
      </div>
    </>
  );
}

export default Header;