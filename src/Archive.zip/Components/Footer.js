import React from "react";
import { ScrollToTop } from '../Helpers/ScrollToTop'
function Footer() {
  const getYear = () => {
    return new Date().getFullYear();
  };
  return (
    <>
      
      <div className=" md:w-full md:mx-auto bg-black text-white text-center p-10 h-6  b-0">
        
        <h2>Copy@right:{getYear()}, All rights reserved</h2>  <ScrollToTop />
      </div>
    </>
  );
}

export default Footer;